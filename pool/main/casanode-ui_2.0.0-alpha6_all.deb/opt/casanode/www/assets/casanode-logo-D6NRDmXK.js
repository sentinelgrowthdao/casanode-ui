const s="/assets/casanode-logo-DaOQl_j6.png";export{s as _};
