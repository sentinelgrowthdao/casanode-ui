System.register([],function(e,t){"use strict";return{execute:function(){e("_","/assets/casanode-logo-DaOQl_j6.png")}}});
